package com.thadocizn.imageviewer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;

import android.os.Bundle;
import android.widget.TextView;

import com.thadocizn.imageviewer.databinding.ActivityMainBinding;

import static com.thadocizn.imageviewer.R.layout.activity_main;

public class MainActivity extends AppCompatActivity {
private ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(activity_main);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

    }

    public TextView generateTextView(String text, int position){
        TextView textView = new TextView(this);
        textView.setTextSize(18);
        textView.setId(position);
        textView.setText(text);
        return textView;
    }
}
